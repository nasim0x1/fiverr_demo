!function () {
    var links = []

    var port = chrome.runtime.connect({
        name: "ml"
    });
    var start = async function () {
        function a() {
            let a = document.querySelectorAll("ytd-guide-section-renderer")[1];
            if (void 0 !== a) {
                let b = a.querySelector("#items > ytd-guide-collapsible-entry-renderer");
                return null === b ? document.createElement("foo") : a.querySelector("#items > ytd-guide-collapsible-entry-renderer").querySelector("#endpoint")
            }
        }
        if (void 0 === a())
            for (document.querySelector("#guide-icon").click(); void 0 === a();) await new Promise(a => setTimeout(a, 500));
        a().click();
        let b = Array.from(document.querySelectorAll("a#endpoint")).filter(a => a.innerHTML.includes("style-scope ytd-guide-entry-renderer no-transition")).map(a => a.href);
        port.postMessage({
            from: "yt_cnls",
            array: b,
            start: null
        });
    };
    start()
}()