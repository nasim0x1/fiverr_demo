var port = chrome.runtime.connect({ name: "nasim" });
$(window).on('pageshow', function () {
    chrome.storage.sync.get(['status'], function (result) {
        if (result.status) {
            inject_notifyer()
            AsyncScroll().then(() => {

                try {
                    port.postMessage({
                        from: "cycle"
                    });

                } catch (error) {
                    var port = chrome.runtime.connect({ name: "nasim" });
                    port.postMessage({
                        from: "cycle"
                    });

                }
            })


        }
    })
})
function AsyncScroll() {
    return new Promise((resolve, reject) => {
        var cycle = setInterval(() => {
            if (document.querySelector("tp-yt-paper-spinner#spinner") == null) {
                clearInterval(cycle)
                resolve();
            }
            try {
                if (!document.querySelector("#spinner").active) {
                    go_to_bottom()
                }
            } catch (error) {
                console.log(error)
            }
        }, 1000);
    });
}


port.onMessage.addListener(function (msg) {
    if (msg.from == "inject_noti") {
        msg_info = msg.msg
    }
})

function inject_notifyer() {
    chrome.storage.sync.get(['message'], function (result) {
        var code = `
        <div class="error-box-alid" style="display:block;width: 250px; background-color: #003049; position: fixed; bottom: 30px; right: 30px;">
        <h2 class="error-box-alid-message" style="color: white;margin: 5px;">
        ${result.message}</h2></div>`
        document.body.insertAdjacentHTML('beforeend', code)
    })
}



function go_to_bottom() {
    let scrollingElement = (document.scrollingElement || document.body);
    scrollingElement.scrollTop = scrollingElement.scrollHeight;
}