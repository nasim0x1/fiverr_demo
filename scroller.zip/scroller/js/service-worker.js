var links = []
var visited = []
var tab_id = 0
var index = 0
chrome.contextMenus.removeAll(function () {

    chrome.contextMenus.create({
        id: 'start',
        title: 'Start Scroller',
        contexts: ['all']
    });
    chrome.contextMenus.create({
        id: 'stop',
        title: 'Stop Scroller',
        contexts: ['all']
    });
})



chrome.runtime.onConnect.addListener(function (port) {
    port.onMessage.addListener(function (msg) {
        if (msg.from === 'yt_cnls') {
            links = msg.array
            if (msg.start != null) {
                index = parseInt(msg.start) - 1
            }
            var msg = `Scrolling ${index + 1}th channel out of ${links.length} channels`
            chrome.storage.sync.set({ message: msg });
            chrome.tabs.update({ url: links[index] + "/videos" })
            index += 1
        }
        if (msg.from === "cycle") {
            if (index == links.length) {
                chrome.tabs.remove(tab_id, () => {
                    chrome.storage.sync.set({ status: false });
                    links = []
                    visited = []
                });
            }
            if (links[index] != undefined && !visited.includes(links[index])) {
                var msg = `Scrolling ${index + 1}th channel out of ${links.length} channels`
                chrome.storage.sync.set({ message: msg });
                chrome.tabs.update({ url: links[index] + "/videos" })
                visited.push(links[index])
                index += 1

            } else {
                chrome.storage.sync.set({ status: false });
            }
        }
    });
});


chrome.contextMenus.onClicked.addListener((info, tabs) => {
    const { menuItemId } = info
    if (menuItemId == "start") {
        index = 0
        links = []
        visited = []
        chrome.storage.sync.set({ status: true });
        chrome.tabs.create({ url: "https://www.youtube.com/" }, function (tab) {
            chrome.scripting.executeScript({
                files: ["js/get_links.js"],
                target: { tabId: tab.id },
            }).then(function () {
                tab_id = tab.id
            });

        });
    }
    if (menuItemId == "stop") {
        chrome.storage.sync.set({ status: false });
    }
});