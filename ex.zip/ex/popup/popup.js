initLogedUi()
var port = chrome.runtime.connect({ name: "ml" });
function save() {
    var new_range = document.getElementById("range").value

    if (new_range === "" || new_range == 0) {
        document.getElementById("current_range").innerHTML = " Range can not be empty or zero"
    } else {
        var val = {}
        var range = document.getElementById("range").value


        var xm1 = document.getElementById("xm1").value
        var xm2 = document.getElementById("xm2").value
        var xm3 = document.getElementById("xm3").value
        var xm4 = document.getElementById("xm4").value
        var xg1 = document.getElementById("xg1").value
        var xg2 = document.getElementById("xg2").value
        var xg3 = document.getElementById("xg3").value
        var xg4 = document.getElementById("xg4").value

        var m1 = document.getElementById("m1").value
        var m2 = document.getElementById("m2").value
        var m3 = document.getElementById("m3").value
        var m4 = document.getElementById("m4").value
        var g1 = document.getElementById("g1").value
        var g2 = document.getElementById("g2").value
        var g3 = document.getElementById("g3").value
        var g4 = document.getElementById("g4").value

        var bm1 = document.getElementById("bm1").value
        var bm2 = document.getElementById("bm2").value
        var bm3 = document.getElementById("bm3").value
        var bm4 = document.getElementById("bm4").value
        var bg1 = document.getElementById("bg1").value
        var bg2 = document.getElementById("bg2").value
        var bg3 = document.getElementById("bg3").value
        var bg4 = document.getElementById("bg4").value

        var cm1 = document.getElementById("cm1").value
        var cm2 = document.getElementById("cm2").value
        var cm3 = document.getElementById("cm3").value
        var cm4 = document.getElementById("cm4").value
        var cg1 = document.getElementById("cg1").value
        var cg2 = document.getElementById("cg2").value
        var cg3 = document.getElementById("cg3").value
        var cg4 = document.getElementById("cg4").value

        var section_a = {}
        var section_b = {}
        var section_c = {}
        var section_x = {}


        section_x['m1'] = xm1
        section_x['m2'] = xm2
        section_x['m3'] = xm3
        section_x['m4'] = xm4
        section_x['g1'] = xg1
        section_x['g2'] = xg2
        section_x['g3'] = xg3
        section_x['g4'] = xg4

        section_a['m1'] = m1
        section_a['m2'] = m2
        section_a['m3'] = m3
        section_a['m4'] = m4
        section_a['g1'] = g1
        section_a['g2'] = g2
        section_a['g3'] = g3
        section_a['g4'] = g4

        section_b['m1'] = bm1
        section_b['m2'] = bm2
        section_b['m3'] = bm3
        section_b['m4'] = bm4
        section_b['g1'] = bg1
        section_b['g2'] = bg2
        section_b['g3'] = bg3
        section_b['g4'] = bg4

        section_c['m1'] = cm1
        section_c['m2'] = cm2
        section_c['m3'] = cm3
        section_c['m4'] = cm4
        section_c['g1'] = cg1
        section_c['g2'] = cg2
        section_c['g3'] = cg3
        section_c['g4'] = cg4

        val["section_a"] = section_a
        val["section_b"] = section_b
        val["section_c"] = section_c
        val["section_x"] = section_x

        val['range'] = range
        val['login'] = true
        val['alert'] = false


        val["a"] = document.getElementById("aa").value
        val["b"] = document.getElementById("bb").value
        val["c"] = document.getElementById("cc").value

        chrome.storage.sync.set({ val: val }, function () {
            document.getElementById("current_range").innerHTML = " " + new_range + " Set successfully"
        });
    }

}


port.onMessage.addListener(function (msg) {
    if (msg.from === "service_login") {
        document.getElementById("loginBTN").innerText = "Login"
        document.getElementById("loginBTN").disable = false
        if (msg.status == true) {
            document.getElementById('main').style.display = "block"
            document.getElementById('login').style.display = "none"
        } else {
            document.getElementById("loginBTN").innerText = "Login"
            document.getElementById("loginBTN").disable = false
            document.getElementById("error_msg").innerHTML = "Username or Password Wrong"
        }
    } else {
        var output = msg.output;
        injectHtml(output);
    }
})

document.getElementById('save').onclick = save;


function initLogedUi() {
    document.getElementById('main').style.display = "block"
    chrome.storage.sync.get(['val'], function (re) {
        var result = re.val
        var a = result.section_a
        var bb = result.section_b
        var cb = result.section_c
        var x = result.section_x

        document.getElementById("current_range").innerHTML = " " + result["range"] + " videos"
        document.getElementById("range").value = result["range"]

        document.getElementById("aa").value = result.a
        document.getElementById("bb").value = result.b
        document.getElementById("cc").value = result.c

        document.getElementById("xm1").value = x["m1"]
        document.getElementById("xm2").value = x["m2"]
        document.getElementById("xm3").value = x["m3"]
        document.getElementById("xm4").value = x["m4"]
        document.getElementById("xg1").value = x["g1"]
        document.getElementById("xg2").value = x["g2"]
        document.getElementById("xg3").value = x["g3"]
        document.getElementById("xg4").value = x["g4"]


        document.getElementById("m1").value = a["m1"]
        document.getElementById("m2").value = a["m2"]
        document.getElementById("m3").value = a["m3"]
        document.getElementById("m4").value = a["m4"]
        document.getElementById("g1").value = a["g1"]
        document.getElementById("g2").value = a["g2"]
        document.getElementById("g3").value = a["g3"]
        document.getElementById("g4").value = a["g4"]

        document.getElementById("bm1").value = bb["m1"]
        document.getElementById("bm2").value = bb["m2"]
        document.getElementById("bm3").value = bb["m3"]
        document.getElementById("bm4").value = bb["m4"]
        document.getElementById("bg1").value = bb["g1"]
        document.getElementById("bg2").value = bb["g2"]
        document.getElementById("bg3").value = bb["g3"]
        document.getElementById("bg4").value = bb["g4"]

        document.getElementById("cm1").value = cb["m1"]
        document.getElementById("cm2").value = cb["m2"]
        document.getElementById("cm3").value = cb["m3"]
        document.getElementById("cm4").value = cb["m4"]
        document.getElementById("cg1").value = cb["g1"]
        document.getElementById("cg2").value = cb["g2"]
        document.getElementById("cg3").value = cb["g3"]
        document.getElementById("cg4").value = cb["g4"]

    })
}