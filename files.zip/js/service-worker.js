try {
    var subscribed_channels_list = []
    const red_gi_videos = new Map()
    var index = 0
    let end
    let copy
    let ws

    chrome.runtime.onInstalled.addListener(() => {
        init()
    });


    chrome.runtime.onConnect.addListener(function (port) {
        port.onMessage.addListener(function (msg) {
            if (ws == null) {
                ws = new WebSocket("ws://localhost:8080");
            }
            if (msg.from === "found_red_gi_video") {
                if (ws.readyState == 1) {
                    send("add", msg.id, msg.data)
                } else {
                    ws.onopen = function (e) {
                        send("add", msg.id, msg.data)
                    }
                }
            }

        })
    })

    function send(work, id, data) {
        console.log(data)
        if (ws == null) {
            ws = new WebSocket("ws://localhost:8080");
        }
        var msg = {
            "do": work,
            "vid": id,
            "data": data
        }
        try {
            ws.send(JSON.stringify(msg))
        } catch (error) {
            if (ws == null) {
                ws = new WebSocket("ws://localhost:8080");
                ws.onopen = function (e) {
                    send(work, id, data)
                }
            }
        }
    }



    function init() {
        var val = {}
        var section_a = {}
        var section_b = {}
        var section_c = {}
        var section_x = {}

        val["a"] = 6
        val["b"] = 12
        val["c"] = 24

        val['range'] = 5
        val['login'] = false
        val['alert'] = true
        val['scroller'] = false


        section_x['m1'] = 0
        section_x['m2'] = 100000
        section_x['m3'] = 500000
        section_x['m4'] = 999999
        section_x['g1'] = 8
        section_x['g2'] = 4
        section_x['g3'] = 2
        section_x['g4'] = 1

        section_a['m1'] = 0
        section_a['m2'] = 100000
        section_a['m3'] = 500000
        section_a['m4'] = 999999
        section_a['g1'] = 0.5
        section_a['g2'] = 0.25
        section_a['g3'] = 0.12
        section_a['g4'] = 0.06

        section_b['m1'] = 0
        section_b['m2'] = 100000
        section_b['m3'] = 500000
        section_b['m4'] = 999999
        section_b['g1'] = 1
        section_b['g2'] = 0.5
        section_b['g3'] = 0.25
        section_b['g4'] = 0.12

        section_c['m1'] = 0
        section_c['m2'] = 100000
        section_c['m3'] = 500000
        section_c['m4'] = 999999
        section_c['g1'] = 2
        section_c['g2'] = 1
        section_c['g3'] = 0.5
        section_c['g4'] = 0.25

        val["section_a"] = section_a
        val["section_b"] = section_b
        val["section_c"] = section_c
        val["section_x"] = section_x

        chrome.storage.sync.get(['val'], function (result) {
            if (result.val === undefined) {
                chrome.storage.sync.set({ val: val }, function () {
                    console.log('Value is set to default value');
                });
            } else {
                default_value = result.val
            }
        })
    }
} catch (error) {
    console.log(error)
}