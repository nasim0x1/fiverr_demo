import os
import json
import asyncio
import websockets
from langdetect import detect

lan_ = []

class Memory:
    def __init__(self) -> None:
        self.videos = {}
        self.lans = []

    def add_video(self, new_video):
        self.videos.update(new_video)
        print(f"Video Added. Total Videos {len(self.videos.keys())}")

    def clear(self):
        self.videos.clear()
        print("Video List Cleared")

    def add_lan(self, lan):
        if lan not in self.lans:
            self.lans.append(lan)

    def save_in_html(self):
        path = f"{os.getcwd()}/htdocs/data.js"
        #path = r"C:\xampp\htdocs\GI\homepage\data.js"

        code = f"var map = {json.dumps(self.videos)};var lans = {str(storage.lans)}"
        with open(path, "w") as html:
            html.write(code)
            html.close()

    def view_formater(self, view):
        view = view.replace(" views", "")
        if "K" in view:
            return int(float(view[:-1]) * 1000)
        if "M" in view:
            return int(float(view[:-1]) * 1000000)
        if "B" in view:
            return int(float(view[:-1]) * 1000000000)
        return int(view)


storage = Memory()


async def echo(websocket):
    async for message in websocket:
        req = json.loads(message)
        if req['do'] == "add":
            data = req["data"]
            print(data['title'])
            data["v"] = storage.view_formater(data["views"])
            if(data['channel_name']) not in lan_:
                try:
                    lan = detect(data["channel_name"])
                    data["lan"] = lan
                    storage.add_lan(lan)
                except:
                    data["lan"] = "Unknow"
                    storage.add_lan(lan)
                lan_.append(data['channel_name'])

            video = {req['vid']: data}
            storage.add_video(video)
        if req['do'] == "clear":
            storage.clear()
        if req['do'] == "save":
            storage.save_in_html()


async def main():
    async with websockets.serve(echo, "localhost", 8080):
        await asyncio.Future()  # run forever
asyncio.run(main())
